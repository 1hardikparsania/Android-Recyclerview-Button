package com.exampledemo.parsaniahardik.recyclerview_button;

/**
 * Created by hardik on 9/1/17.
 */
public class Model {

    private int number;
    private String fruit;

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getFruit() {
        return fruit;
    }

    public void setFruit(String fruit) {
        this.fruit = fruit;
    }
}
